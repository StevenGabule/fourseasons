create definer = root@localhost view customer_bookings_c as
select `fourseasons`.`bookings`.`id`                                                       AS `booking_id`,
       `fourseasons`.`bookings`.`customer_id`                                              AS `customer_id`,
       `fourseasons`.`bookings`.`service_date_start`                                       AS `service_date_start`,
       `fourseasons`.`bookings`.`service_date_end`                                         AS `service_date_end`,
       `fourseasons`.`bookings`.`service_time`                                             AS `service_time`,
       `fourseasons`.`bookings`.`service_type`                                             AS `service_type`,
       `fourseasons`.`bookings`.`frequency`                                                AS `frequency`,
       `fourseasons`.`bookings`.`duration`                                                 AS `duration`,
       `fourseasons`.`bookings`.`status`                                                   AS `status`,
       `fourseasons`.`customers`.`id`                                                      AS `id`,
       `fourseasons`.`customers`.`fullName`                                                AS `fullName`,
       `fourseasons`.`customers`.`email`                                                   AS `email`,
       concat(`fourseasons`.`customers`.`address`, ' ', `fourseasons`.`customers`.`home_apartment_number`, ' ',
              `fourseasons`.`customers`.`city`, ' ', `fourseasons`.`customers`.`postcode`) AS `location`
from (`fourseasons`.`bookings`
         join `fourseasons`.`customers` on ((`fourseasons`.`bookings`.`customer_id` = `fourseasons`.`customers`.`id`)))
where (`fourseasons`.`bookings`.`status` = 1)
order by `fourseasons`.`bookings`.`status` desc;

-- comment on column customer_bookings_c.status not supported: 0-process|1-Com|2-Can|3-fraud

